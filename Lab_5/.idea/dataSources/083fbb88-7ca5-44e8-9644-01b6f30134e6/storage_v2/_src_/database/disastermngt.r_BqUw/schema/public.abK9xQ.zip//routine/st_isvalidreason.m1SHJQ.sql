create function st_isvalidreason(geometry, integer) returns text
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT CASE WHEN valid THEN 'Valid Geometry' ELSE reason END FROM (
		SELECT (public.ST_isValidDetail($1, $2)).*
	) foo

$$;

comment on function st_isvalidreason(geometry, integer) is 'args: geomA, flags - Returns text stating if a geometry is valid, or a reason for invalidity.';

alter function st_isvalidreason(geometry, integer) owner to postgres;

